// server.js — local proxy + dashboard host for Dhan API
// Run with:  bun server.js
// Then open: http://localhost:4000

const PORT = 4000;
const SCRIP_MASTER_URL = "https://images.dhan.co/api-data/api-scrip-master.csv";
const SCRIP_CACHE_FILE = "./scrip-master-cache.csv";

let ACCESS_TOKEN = null;
let scripRows = [];        // [{symbol, customSymbol, symbolName, securityId, exch, segment, instrument}]
let scripLoadedAt = null;

// authoritative Dhan index list (user-supplied, exact security ids — not scrip-master fuzzy matched)
const INDEX_LIST = JSON.parse(require("fs").readFileSync("./index_list.json", "utf8"));
// { exch, securityId, symbol, name }[]


// ---------- tiny CSV parser (handles quoted commas) ----------
function parseCSV(text) {
  const lines = text.split(/\r?\n/);
  if (!lines.length) return { headers: [], rows: [] };
  const splitLine = (line) => {
    const cells = [];
    let cur = "", inQ = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') { inQ = !inQ; continue; }
      if (ch === "," && !inQ) { cells.push(cur); cur = ""; continue; }
      cur += ch;
    }
    cells.push(cur);
    return cells;
  };
  const headers = splitLine(lines[0]).map((h) => h.trim());
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    if (!lines[i] || !lines[i].trim()) continue;
    const cells = splitLine(lines[i]);
    const obj = {};
    headers.forEach((h, idx) => (obj[h] = (cells[idx] ?? "").trim()));
    rows.push(obj);
  }
  return { headers, rows };
}

// ---------- load & cache the Dhan scrip master ----------
async function loadScripMaster() {
  let text;
  try {
    console.log("Fetching Dhan scrip master...");
    const res = await fetch(SCRIP_MASTER_URL);
    if (!res.ok) throw new Error("HTTP " + res.status);
    text = await res.text();
    await Bun.write(SCRIP_CACHE_FILE, text);
    console.log("Scrip master downloaded and cached.");
  } catch (e) {
    console.warn("Could not fetch scrip master live (" + e.message + "), trying cache...");
    const cacheFile = Bun.file(SCRIP_CACHE_FILE);
    if (await cacheFile.exists()) {
      text = await cacheFile.text();
      console.log("Loaded scrip master from local cache.");
    } else {
      console.error("No scrip master available (no network, no cache). Symbol lookups will fail.");
      return;
    }
  }
  const { rows } = parseCSV(text);
  scripRows = rows.map((r) => ({
    symbol: r["SEM_TRADING_SYMBOL"] || "",
    customSymbol: r["SEM_CUSTOM_SYMBOL"] || "",
    symbolName: r["SM_SYMBOL_NAME"] || "",
    securityId: r["SEM_SMST_SECURITY_ID"] || "",
    exch: r["SEM_EXM_EXCH_ID"] || "",
    segment: r["SEM_SEGMENT"] || "",
    instrument: r["SEM_INSTRUMENT_NAME"] || "",
  }));
  scripLoadedAt = new Date();
  console.log("Scrip master ready:", scripRows.length, "rows");
}

// ---------- lookup helpers ----------
function findEquity(symbol) {
  const s = symbol.trim().toUpperCase();
  // exact match on NSE equity first
  let hit = scripRows.find(
    (r) => r.exch === "NSE" && r.segment === "E" && r.instrument === "EQUITY" && r.symbol.toUpperCase() === s
  );
  if (!hit) {
    hit = scripRows.find(
      (r) => r.exch === "NSE" && r.segment === "E" && r.symbol.toUpperCase() === s
    );
  }
  if (!hit) {
    // fall back to custom symbol match
    hit = scripRows.find(
      (r) => r.exch === "NSE" && r.segment === "E" && r.customSymbol.toUpperCase().startsWith(s)
    );
  }
  return hit || null;
}

function searchScrip(query) {
  const q = query.trim().toUpperCase();
  if (!q) return [];
  return scripRows
    .filter(
      (r) =>
        r.symbol.toUpperCase().includes(q) ||
        r.symbolName.toUpperCase().includes(q) ||
        r.customSymbol.toUpperCase().includes(q)
    )
    .slice(0, 25);
}

function resolveIndex(name) {
  const key = name.trim().toUpperCase();
  let hit = INDEX_LIST.find((r) => r.symbol.toUpperCase() === key || r.name.toUpperCase() === key);
  if (hit) return { securityId: hit.securityId, exch: "IDX_I", matchedName: hit.name };
  hit = INDEX_LIST.find((r) => r.symbol.toUpperCase().includes(key) || r.name.toUpperCase().includes(key));
  if (hit) return { securityId: hit.securityId, exch: "IDX_I", matchedName: hit.name };
  return null;
}

function searchIndices(query) {
  const q = query.trim().toUpperCase();
  if (!q) return INDEX_LIST.slice(0, 30);
  return INDEX_LIST.filter((r) => r.symbol.toUpperCase().includes(q) || r.name.toUpperCase().includes(q)).slice(0, 30);
}

// ---------- Dhan API call (server-side, no CORS issue) ----------
async function fetchIntraday({ securityId, exchangeSegment, instrument, interval, fromDate, toDate }) {
  if (!ACCESS_TOKEN) throw new Error("No access token set. Paste today's Dhan token in the dashboard first.");
  const res = await fetch("https://api.dhan.co/v2/charts/intraday", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "access-token": ACCESS_TOKEN,
    },
    body: JSON.stringify({
      securityId: String(securityId),
      exchangeSegment,
      instrument,
      interval: String(interval),
      fromDate,
      toDate,
    }),
  });
  const text = await res.text();
  if (!res.ok) throw new Error("Dhan API error " + res.status + ": " + text.slice(0, 300));
  let data;
  try { data = JSON.parse(text); } catch { throw new Error("Dhan returned non-JSON: " + text.slice(0, 200)); }
  return data;
}

// ---------- HTTP server ----------
function json(body, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { "Content-Type": "application/json" },
  });
}

const server = Bun.serve({
  port: PORT,
  async fetch(req) {
    const url = new URL(req.url);

    if (url.pathname === "/" || url.pathname === "/index.html") {
      const file = Bun.file("./dashboard.html");
      if (await file.exists()) return new Response(file, { headers: { "Content-Type": "text/html" } });
      return new Response("dashboard.html not found next to server.js", { status: 404 });
    }

    if (url.pathname === "/api/status") {
      return json({
        scripLoaded: scripRows.length > 0,
        scripRows: scripRows.length,
        scripLoadedAt,
        hasToken: !!ACCESS_TOKEN,
      });
    }

    if (url.pathname === "/api/set-token" && req.method === "POST") {
      const body = await req.json().catch(() => ({}));
      if (!body.token) return json({ error: "token missing" }, 400);
      ACCESS_TOKEN = body.token.trim();
      return json({ ok: true });
    }

    if (url.pathname === "/api/resolve-index") {
      const name = url.searchParams.get("name") || "";
      const result = resolveIndex(name);
      return result ? json(result) : json({ error: "not found" }, 404);
    }

    if (url.pathname === "/api/indices") {
      const q = url.searchParams.get("q") || "";
      return json({ results: searchIndices(q) });
    }

    if (url.pathname === "/api/search-symbol") {
      const q = url.searchParams.get("q") || "";
      return json({ results: searchScrip(q) });
    }

    if (url.pathname === "/api/ohlc") {
      try {
        const symbol = url.searchParams.get("symbol");
        const kind = url.searchParams.get("kind") || "equity"; // equity | index
        const interval = url.searchParams.get("interval") || "15";
        const fromDate = url.searchParams.get("from");
        const toDate = url.searchParams.get("to");
        const overrideId = url.searchParams.get("securityId");
        const overrideExch = url.searchParams.get("exchSegment");
        if (!symbol || !fromDate || !toDate) return json({ error: "symbol, from, to are required" }, 400);

        let securityId, exchangeSegment, instrument;
        if (overrideId) {
          securityId = overrideId;
          exchangeSegment = overrideExch || (kind === "index" ? "IDX_I" : "NSE_EQ");
          instrument = kind === "index" ? "INDEX" : "EQUITY";
        } else if (kind === "index") {
          const idx = resolveIndex(symbol);
          if (!idx) return json({ error: "Could not resolve index '" + symbol + "' in scrip master — set a manual security ID override" }, 404);
          securityId = idx.securityId;
          exchangeSegment = "IDX_I";
          instrument = "INDEX";
        } else {
          const eq = findEquity(symbol);
          if (!eq) return json({ error: "Could not resolve symbol '" + symbol + "' in scrip master" }, 404);
          securityId = eq.securityId;
          exchangeSegment = "NSE_EQ";
          instrument = "EQUITY";
        }

        const data = await fetchIntraday({ securityId, exchangeSegment, instrument, interval, fromDate, toDate });
        return json({ symbol, securityId, exchangeSegment, ...data });
      } catch (e) {
        return json({ error: e.message }, 500);
      }
    }

    return new Response("Not found", { status: 404 });
  },
});

console.log("Dhan proxy + dashboard running at http://localhost:" + PORT);
loadScripMaster();
